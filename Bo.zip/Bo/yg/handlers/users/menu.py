from aiogram.dispatcher.filters import Command, Text
from aiogram.types import Message
from keyboards.default import menu, buy, back1, chat1, buy1
from loader import dp

@dp.message_handler(Command("menu"))
async def show_menu(message: Message):
	await message.answer("Выберете действие:",
reply_markup=menu)

@dp.message_handler(Text(equals=["Продавец"]))
async def Seller(message: Message):
	await message.answer("Заполните форму, чтобы зарегистрироваться в нашем сервисе:"
						 "https://docs.google.com/forms/d/e/1FAIpQLSdQym7q_5QQdtkQClhhbuVqE9iHWSEeErtnIPkoyR8oWqkRaw/viewform?usp=sf_link",
reply_markup=back1)
	await message.answer("Чтобы вернуться в меню нажмите 'Назад'")

@dp.message_handler(Text(equals=["Покупатель"]))
async def Customer(message: Message):
	await message.answer("Переход в раздел покупателя",
reply_markup=buy)

@dp.message_handler(Text(equals=["Обратная связь"]))
async def Customer(message: Message):
	await message.answer("Если у вас, есть какие то вопросы, пожелания свяжитесь с нами: "
						 "https://docs.google.com/forms/d/e/1FAIpQLSckpl8wRZ2d-k6ZT8o9Vomaw2CqXuxzU97qeiCFXDOPCQuVhw/viewform?usp=sf_link ",
reply_markup=back1)
	await message.answer("Чтобы вернуться в меню нажмите 'Назад'")