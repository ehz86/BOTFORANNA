from loader import dp
from aiogram.types import Message
from keyboards.default import buy, link2
from aiogram.dispatcher.filters import Text

@dp.message_handler(Text(equals=["Назад к покупкам"]))
async def back_to_buy(message: Message):
	await message.answer("Возвращение в меню выбора кондитеров",
	reply_markup=buy)

