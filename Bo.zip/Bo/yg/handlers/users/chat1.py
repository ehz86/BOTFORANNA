user_dict = {}
class User:
    def __init__(self, first_name):
        self.name = name
        self.age = None
        self.sex = None

