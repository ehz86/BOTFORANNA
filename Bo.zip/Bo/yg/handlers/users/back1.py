from loader import dp
from aiogram.types import Message
from keyboards.default import menu,back1
from aiogram.dispatcher.filters import Text

@dp.message_handler(Text(equals=["Назад"]))
async def Seller(message: Message):
	await message.answer("Возвращение в меню",
	reply_markup=menu)
