import types
from data import config
from aiogram import Bot
from aiogram import types
from aiogram.dispatcher.filters import Text
from aiogram.types import Message
from keyboards.default import buy1, menu, categories
from loader import dp
bot = Bot(token=config.BOT_TOKEN)

@dp.message_handler(Text(equals=["Показать весь список"]))
async def Customer(message: Message):
	await message.answer("Переход в раздел покупателя",
reply_markup=buy1)
	await message.answer("Выберете Кондитера:")
	await message.answer("catherines_bakery Екатерина- твой кондитер. Готовлю одни из лучших тортов и пироженных в городе. Вкусное удовольствие от 1899 рублей")
	media = types.MediaGroup()
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/1.jpeg'))
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/2.jpeg'))
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/3.jpeg'))
	await message.answer_media_group(media=media)
	await message.answer("_tasha_cakes_nn Привет, мы кондитеры Таня и Маша и уже больше 3 лет мы радуем всех своими тортами и пироженными. Цена: 1500 рублей за кг(торт от 2 кг) ")
	media = types.MediaGroup()
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/4.jpeg','Тортики'))
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/5.jpeg','Тортики'))
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/6.jpeg','Тортики'))
	await  message.answer_media_group(media=media)
	await message.answer("candylandnnov Лучший кондитер в вашем городе с самыми низкими ценами. 🎂Торты от 1090 р за кг (min 2 КГ)")
	media = types.MediaGroup()
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/7.jpeg', 'Тортики'))
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/8.jpeg', 'Тортики'))
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/9.jpeg', 'Тортики'))
	await  message.answer_media_group(media=media)
	await message.answer("yourcake52 ️Я - Юлия.Дарю сладкие эмоции! Больше 2-х лет на рынке. Торты от 2000 рублей, так же возможны скидки) ")
	media = types.MediaGroup()
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/10.jpeg', 'Тортики'))
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/11.jpeg', 'Тортики'))
	media.attach_photo(types.InputFile('/Users/egorhohlov/Downloads/фото бот/12.jpeg', 'Тортики'))
	await  message.answer_media_group(media=media)
	await message.answer("Чтобы вернуться в меню нажмите 'Назад'")

@dp.message_handler(Text(equals=["Выбрать категорию"]))
async def Customer(message: Message):
	await message.answer("Переход к выбору категории",
reply_markup=categories)

@dp.message_handler(Text(equals=["Назад"]))
async def back_to_menu(message: Message):
	await message.answer("Возвращение в меню",
	reply_markup=menu)

