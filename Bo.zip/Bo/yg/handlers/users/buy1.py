from loader import dp
from aiogram.types import Message
from keyboards.default import menu, link, link2, link3, link4
from aiogram.dispatcher.filters import Text
from data import config
from aiogram import Bot
bot = Bot(token=config.BOT_TOKEN)

@dp.message_handler(Text(equals=["catherines_bakery"]))
async def Seller1(message: Message):

	await message.answer("https://www.instagram.com/catherines_bakery/")
	await message.answer("catherines_bakery", reply_markup=link)

@dp.message_handler(Text(equals=["_tasha_cakes_nn"]))
async def Seller2(message: Message):
	await message.answer("https://www.instagram.com/_tasha_cakes_nn/")
	await message.answer("_tasha_cakes_nn",reply_markup=link2)

@dp.message_handler(Text(equals=["candylandnnov"]))
async def Seller3(message: Message):
	await message.answer("https://www.instagram.com/candylandnnov/")
	await message.answer("candylandnnov",reply_markup=link3)

@dp.message_handler(Text(equals=["yourcake52"]))
async def Seller4(message: Message):
	await message.answer("https://www.instagram.com/yourcake52/")
	await message.answer("yourcake52",reply_markup=link4)

@dp.message_handler(Text(equals=["Назад"]))
async def back_to_menu(message: Message):
	await message.answer("Возвращение в меню",
	reply_markup=menu)

