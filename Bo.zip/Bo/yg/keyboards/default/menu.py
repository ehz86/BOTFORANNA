from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

menu = ReplyKeyboardMarkup(
	keyboard=[
		[
			KeyboardButton(text="Продавец")
		],
		[
			KeyboardButton(text="Покупатель")
		],
[
			KeyboardButton(text="Обратная связь")
		],
	],
	resize_keyboard=True
)