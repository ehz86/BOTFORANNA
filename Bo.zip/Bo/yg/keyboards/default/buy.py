from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

buy = ReplyKeyboardMarkup(
	keyboard =[
		[
			KeyboardButton(text="Выбрать категорию")
		],
		[
			KeyboardButton(text="Показать весь список")
		],
		[
			KeyboardButton(text="Назад")
		],
	],
	resize_keyboard=True
)