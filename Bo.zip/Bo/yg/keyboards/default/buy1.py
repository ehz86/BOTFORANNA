from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

buy1 = ReplyKeyboardMarkup(
	keyboard=[
		[
			KeyboardButton(text="catherines_bakery")
		],
		[
			KeyboardButton(text="_tasha_cakes_nn")
		],
		[
			KeyboardButton(text="candylandnnov")
		],
		[
			KeyboardButton(text="yourcake52")
		],
[
			KeyboardButton(text="Назад")
		],
	],
	resize_keyboard=True
)