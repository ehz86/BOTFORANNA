from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

link2 = ReplyKeyboardMarkup(
	keyboard =[
		[
			KeyboardButton(text="Назад к покупкам")
		],
	],
	resize_keyboard=True
)