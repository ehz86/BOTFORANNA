from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
chat1 = ReplyKeyboardMarkup(
	keyboard =[
		[
			KeyboardButton(text="кнопка")
		],
	],
	resize_keyboard=True
)