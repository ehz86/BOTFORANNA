from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
categories = ReplyKeyboardMarkup(
	keyboard =	[
		[
			KeyboardButton(text="Шоколадный торт")
		],
		[
			KeyboardButton(text="Торты без использования животных добавок(vegan)")
		],
		[
			KeyboardButton(text="Диетические торты")
		],
		[
			KeyboardButton(text="Назад")
		],
	],
	resize_keyboard=True
)