from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

back1 = ReplyKeyboardMarkup(
	keyboard =	[
		[
			KeyboardButton(text="Назад")
		],
	],
	resize_keyboard=True
)