from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

link3 = ReplyKeyboardMarkup(
	keyboard =[
		[
			KeyboardButton(text="Назад к покупкам")
		],
	],
	resize_keyboard=True
)